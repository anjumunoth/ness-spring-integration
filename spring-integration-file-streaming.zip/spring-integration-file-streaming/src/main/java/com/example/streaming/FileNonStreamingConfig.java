package com.example.streaming;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.dsl.Files;

import java.io.File;
import java.util.List;

@Configuration
public class FileNonStreamingConfig {

    private static final String INPUT_DIR = "inputWithoutStream";
    private static final String PROCESSED_DIR = "processedWithoutStream";

    @Bean
    public IntegrationFlow fileFlow() {

        return IntegrationFlow
                .from(Files.inboundAdapter(new File(INPUT_DIR))
                                .autoCreateDirectory(true),
                        e -> e.poller(Pollers.fixedDelay(5000)))

                // ❌ Load entire file into memory
                .transform(File.class, file -> {
                    try {
                        // Reads ALL lines into memory
                        List<String> lines = java.nio.file.Files.readAllLines(file.toPath());
                        return lines;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                })


                .handle((payload, headers) -> {
                    String fileContents = payload.toString();
                    System.out.println("Processing Entire file: " + fileContents);
                    return null;
                })
//
//                // Move file after processing
//                .handle(Files.outboundAdapter(new File(PROCESSED_DIR))
//                        .autoCreateDirectory(true)
//                        .deleteSourceFiles(true))

                .get();
    }
}
