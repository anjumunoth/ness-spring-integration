
package com.example.streaming;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.dsl.Files;
import org.springframework.messaging.Message;

import java.io.File;
import java.io.IOException;

@Configuration
public class FileStreamingConfig {

    // Input directory where files will be picked from
    private static final String INPUT_DIR = "input";

    // Directory where successfully processed files will be moved
    private static final String PROCESSED_DIR = "processed";

    // Directory where failed files will be moved
    private static final String ERROR_DIR = "error";

    @Bean
    public IntegrationFlow fileStreamingFlow() {

        return IntegrationFlow

                // 🔹 Step 1: File Inbound Adapter
                // Watches the INPUT_DIR for new files
                .from(Files.inboundAdapter(new File(INPUT_DIR))
                                .autoCreateDirectory(true) // creates folder if not present
                                .preventDuplicates(true),  // avoids re-processing same file
                        e -> e.poller(Pollers.fixedDelay(5000) // poll every 5 seconds
                                .maxMessagesPerPoll(1)        // process 1 file at a time
                                .errorChannel("fileErrorChannel"))) // send errors to this channel

                // 🔹 Step 2: Split file into lines (STREAMING)
                .split(Files.splitter()
                        .markers()              // adds START and END marker messages
                        .applySequence(true))   // adds sequence metadata (order info)

                // 🔹 Step 3: Route messages based on marker
                .route(Message.class, message -> {
                            // Extract marker from message headers
                            Object marker = message.getHeaders().get("file_marker");

                            // If marker exists → return START / END
                            // Else → treat as LINE (actual file content)
                            return marker != null ? marker.toString() : "LINE";
                        }, mapping -> mapping

                                // ✅ LINE: Actual file content processing
                                .subFlowMapping("LINE", sf -> sf
                                        .handle(message -> {
                                            // Extract line content
                                            String line = message.getPayload().toString();

                                            System.out.println("Processing line: " + line);

                                            // Example validation logic
                                            if (line.contains("ERROR")) {
                                                throw new RuntimeException("Invalid data: " + line);
                                            }

                                            // No return → one-way handler → flow ends here
                                        }) // terminal handler (no further processing)
                                )

                                // ✅ END: File processing completed
                                .subFlowMapping("END", sf -> sf
                                        .handle(message -> {
                                            try {
                                                // Get original file from headers
                                                Object fileObj = message.getHeaders().get("file_originalFile");

                                                // Convert safely to File object
                                                File file = (fileObj instanceof File)
                                                        ? (File) fileObj
                                                        : new File(fileObj.toString());

                                                // Target location for processed file
                                                File target = new File(PROCESSED_DIR, file.getName());

                                                // 🔥 Move file safely (better than renameTo)
                                                java.nio.file.Files.move(
                                                        file.toPath(),
                                                        target.toPath(),
                                                        java.nio.file.StandardCopyOption.REPLACE_EXISTING
                                                );

                                                System.out.println("✅ File moved to processed: " + file.getName());

                                            } catch (Exception e) {
                                                // Wrap and rethrow to trigger error flow
                                                throw new RuntimeException(e);
                                            }
                                        })
                                )

                                // ✅ START: Beginning of file (no processing needed)
                                .subFlowMapping("START", sf -> sf
                                        .channel("nullChannel") // drop message safely
                                )
                )

                .get(); // build the flow
    }

    // 🔴 ERROR HANDLING FLOW
    @Bean
    public IntegrationFlow errorHandlingFlow() {

        return IntegrationFlow
                // Listen to error channel
                .from("fileErrorChannel")

                // Handle any exception from main flow
                .handle(message -> {
                    System.out.println("❌ Error: " + message);

                    // Extract original file from headers
                    Object fileObj = message.getHeaders().get("file_originalFile");

                    if (fileObj != null) {
                        // Convert to File safely
                        File file = (fileObj instanceof File)
                                ? (File) fileObj
                                : new File(fileObj.toString());

                        // Move file to error directory
                        File target = new File(ERROR_DIR, file.getName());

                        // 🔥 Move file safely (better than renameTo)
                        try {
                            java.nio.file.Files.move(
                                    file.toPath(),
                                    target.toPath(),
                                    java.nio.file.StandardCopyOption.REPLACE_EXISTING
                            );
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }


                        System.out.println("Moved to error: " + file.getName());
                    }
                })

                .get(); // build error flow
    }
}