# Spring Integration File Streaming (Spring Boot 4.0.3)

## How to Run
1. Place a file inside /input directory
2. Run: mvn spring-boot:run
3. Watch logs for line-by-line processing
4. File will move to /processed after completion

## Features
- Streaming (Files.lines)
- No full file load into memory
- Splitter (line-by-line)
- Backpressure (poller)
- Auto move processed files
