package com.example.securityExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityExampleApplication.class, args);
	}

}
/*

# 🧪 1. Start Your Application

Run your Spring Boot app:

```bash
mvn spring-boot:run
```

Make sure it’s running on:

```
http://localhost:8080
```

---

# 🟢 2. Test Public API (No Auth)

### In Postman:

* Method: **GET**
* URL:

```
http://localhost:8080/public
```

👉 No authentication needed

### Expected Response:

```
Public API - No authentication required
```

---

# 🔐 3. Test Secure API (Authentication)

### In Postman:

* Method: **GET**
* URL:

```
http://localhost:8080/secure
```

### 👉 Go to **Authorization tab**

* Type: **Basic Auth**
* Username: `user`
* Password: `password`

---

### ✅ What Postman does internally:

It sends:

```
Authorization: Basic base64(user:password)
```

---

### Expected Response:

```
Authenticated User: user
```

---

# 🔄 4. Test Integration Flow (MOST IMPORTANT)

This is where everything clicks.

---

## In Postman:

### Step 1: Request setup

* Method: **POST**
* URL:

```
http://localhost:8080/send
```

---

### Step 2: Authorization tab

* Type: **Basic Auth**
* Username: `user`
* Password: `password`

---

### Step 3: Body tab

* Select: **raw**
* Type: **Text**
* Body:

```
Hello Secure Flow
```

---

### Step 4: Send request

---

## ✅ Expected Response:

```
Message sent by user
```

---

## 🖥️ Check Console Logs

You should see:

```
=== MESSAGE RECEIVED ===
Payload: Hello Secure Flow
User: user
```

---

# 🔥 What You Just Verified (IMPORTANT)

You literally tested:

```text
Postman → Spring Security (auth) → Controller → Spring Integration → Flow
```

---

# ❗ 5. Common Mistakes (Very Important)

### ❌ 401 Unauthorized

👉 Cause: Forgot Basic Auth
✔ Fix: Add username/password in Postman

---

### ❌ 403 Forbidden

👉 Cause: Authenticated but not allowed (not in this example yet)

---

### ❌ 415 Unsupported Media Type

👉 Fix:
Set Body → **raw → Text**

---


| Step                  | What happens          |
| --------------------- | --------------------- |
| Postman sends request | With credentials      |
| Spring Security       | Authenticates user    |
| Controller            | Gets `Authentication` |
| Integration Flow      | Uses same user        |

 */
