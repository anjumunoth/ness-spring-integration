package com.example.securityExample;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.*;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.security.core.Authentication;

@Configuration
public class IntegrationConfig {

    @Bean
    public MessageChannel inputChannel() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow flow() {
        return IntegrationFlow.from("inputChannel")
                .handle(message -> {
                    Authentication auth = (Authentication) message.getHeaders().get("auth");

                    System.out.println("=== MESSAGE RECEIVED ===");
                    System.out.println("Payload: " + message.getPayload());
                    System.out.println("User: " + auth.getName());
                })
                .get();
    }
}
