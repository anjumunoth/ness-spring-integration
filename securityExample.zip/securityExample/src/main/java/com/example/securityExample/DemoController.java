package com.example.securityExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.messaging.*;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.security.core.Authentication;

@RestController
public class DemoController {

    @Autowired
    private MessageChannel inputChannel;

    @GetMapping("/public")
    public String publicApi() {
        return "Public API - No authentication required";
    }

    @GetMapping("/secure")
    public String secureApi(Authentication authentication) {
        return "Authenticated User: " + authentication.getName();
    }

    @PostMapping("/send")
    public String sendMessage(@RequestBody String payload, Authentication authentication) {

        Message<String> message = MessageBuilder.withPayload(payload)
                .setHeader("auth", authentication)
                .build();

        inputChannel.send(message);

        return "Message sent by " + authentication.getName();
    }
}

