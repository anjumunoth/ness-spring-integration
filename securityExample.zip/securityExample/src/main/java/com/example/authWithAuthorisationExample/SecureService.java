package com.example.authWithAuthorisationExample;

import org.springframework.messaging.Message;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
public class SecureService {

    @PreAuthorize("hasRole('USER')")
    public void userProcess(Message<?> message) {
        Authentication auth = (Authentication) message.getHeaders().get("auth");

        System.out.println("=== USER FLOW ===");
        System.out.println("Payload: " + message.getPayload());
        System.out.println("User: " + auth.getName());
    }

    @PreAuthorize("hasRole('ADMIN')")
    public void adminProcess(Message<?> message) {
        Authentication auth = (Authentication) message.getHeaders().get("auth");

        System.out.println("=== ADMIN FLOW ===");
        System.out.println("Payload: " + message.getPayload());
        System.out.println("Admin User: " + auth.getName());
    }
}
