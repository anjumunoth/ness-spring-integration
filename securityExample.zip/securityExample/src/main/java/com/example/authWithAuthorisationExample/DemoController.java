package com.example.authWithAuthorisationExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.messaging.*;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.security.core.Authentication;

@RestController
public class DemoController {

    @Autowired
    private MessageChannel inputChannel;

    @Autowired
    private MessageChannel adminChannel;

    @GetMapping("/public")
    public String publicApi() {
        return "Public API - No authentication required";
    }

    @GetMapping("/secure")
    public String secureApi(Authentication authentication) {
        return "Authenticated User: " + authentication.getName();
    }

    // USER FLOW
    @PostMapping("/send")
    public String sendMessage(@RequestBody String payload, Authentication authentication) {

        Message<String> message = MessageBuilder.withPayload(payload)
                .setHeader("auth", authentication)
                .build();

        inputChannel.send(message);

        return "Message sent to USER flow by " + authentication.getName();
    }

    // ADMIN FLOW
    @PostMapping("/admin/send")
    public String sendAdminMessage(@RequestBody String payload, Authentication authentication) {

        Message<String> message = MessageBuilder.withPayload(payload)
                .setHeader("auth", authentication)
                .build();

        adminChannel.send(message);

        return "Message sent to ADMIN flow by " + authentication.getName();
    }
}

