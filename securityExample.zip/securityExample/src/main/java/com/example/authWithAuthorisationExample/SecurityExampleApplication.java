package com.example.authWithAuthorisationExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityExampleApplication.class, args);
	}

}

/*

# 🧪 1. Start the Application

Run:

```bash
mvn spring-boot:run
```

App runs at:

```text
http://localhost:8080
```

---

# 🧠 2. What You Are Testing

```text
Postman
  ↓
Spring Security (Authentication)
  ↓
Controller
  ↓
Integration Flow
  ↓
SecureService (@PreAuthorize)
  ↓
ALLOW / DENY
```

---

# 🟢 3. Test Public API (No Auth)

### Request

* Method: **GET**
* URL:

```
http://localhost:8080/public
```

### Expected Response

```
Public API - No authentication required
```

---

# 🔐 4. Test Authentication

### Request

* Method: **GET**
* URL:

```
http://localhost:8080/secure
```

### In Postman → Authorization tab

* Type: **Basic Auth**
* Username: `user`
* Password: `password`

### Expected

```
Authenticated User: user
```

---

# 🔄 5. Test USER Flow (Allowed)

### Request

* Method: **POST**
* URL:

```
http://localhost:8080/send
```

### Authorization

* Basic Auth
* `user / password`

### Body (raw → text)

```
Hello from USER
```

### Expected Response

```
Message sent to USER flow by user
```

### Console Output

```
=== USER FLOW ===
Payload: Hello from USER
User: user
```

---

# ❌ 6. Test USER accessing ADMIN Flow (Denied)

### Request

* Method: **POST**
* URL:

```
http://localhost:8080/admin/send
```

### Auth

* `user / password`

### Expected

```
403 Forbidden
```

### Why?

```text
@PreAuthorize("hasRole('ADMIN')")
→ user has only ROLE_USER
→ access denied
```

---

# 🔐 7. Test ADMIN Flow (Allowed)

### Request

* Method: **POST**
* URL:

```
http://localhost:8080/admin/send
```

### Auth

* `admin / password`

### Body

```
Hello from ADMIN
```

### Expected Response

```
Message sent to ADMIN flow by admin
```

### Console Output

```
=== ADMIN FLOW ===
Payload: Hello from ADMIN
Admin User: admin
```

---

# ⚠️ 8. Common Errors (and Fixes)

---

## ❌ 401 Unauthorized

👉 Missing or wrong credentials
✔ Fix: Add Basic Auth in Postman

---

## ❌ 403 Forbidden

👉 RBAC working correctly
✔ Happens when USER hits ADMIN endpoint

---

## ❌ 500 Internal Server Error

👉 Likely missing this in controller:

```java
.setHeader("auth", authentication)
```

---

## ❌ No logs in console

👉 Flow not triggered
✔ Check:

* Correct endpoint
* Correct channel name

---


| Step             | What happens        |
| ---------------- | ------------------- |
| Postman          | Sends credentials   |
| Spring Security  | Authenticates user  |
| Controller       | Gets Authentication |
| Integration Flow | Routes message      |
| SecureService    | Enforces RBAC       |

---


 */
