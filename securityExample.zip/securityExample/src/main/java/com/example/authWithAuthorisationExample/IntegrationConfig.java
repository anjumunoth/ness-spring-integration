package com.example.authWithAuthorisationExample;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;

import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;

// ✅ CORRECT IMPORTS FOR SPRING BOOT 4.0.4
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.authorization.AuthorityAuthorizationManager;
import org.springframework.security.messaging.access.intercept.MessageMatcherDelegatingAuthorizationManager;
import org.springframework.security.messaging.access.intercept.AuthorizationChannelInterceptor;
import org.springframework.stereotype.Service;

@Configuration
public class IntegrationConfig {

    // ======================
    // CHANNELS
    // ======================

    @Bean
    public MessageChannel inputChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageChannel adminChannel() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow userFlow() {
        return IntegrationFlow.from("inputChannel")
                .handle("secureService", "userProcess")
                .get();
    }

    @Bean
    public IntegrationFlow adminFlow() {
        return IntegrationFlow.from("adminChannel")
                .handle("secureService", "adminProcess")
                .get();
    }
}



